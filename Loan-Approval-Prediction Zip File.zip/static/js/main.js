document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('form[aria-label="Loan prediction form"]');
  const predictBtn = document.getElementById('predict_btn');
  const clearBtn = document.getElementById('clear_btn');

  if (!form || !predictBtn) return;

  form.addEventListener('submit', function (e) {
    // Let HTML5 validation run first
    if (!form.checkValidity()) {
      // Find first invalid field and focus it
      const firstInvalid = form.querySelector(':invalid');
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    // Disable submit to prevent double-posts
    predictBtn.disabled = true;
    predictBtn.dataset.orig = predictBtn.innerHTML;
    predictBtn.innerHTML = 'Predicting... <span class="spinner" aria-hidden="true"></span>';
  });

  if (clearBtn) {
    clearBtn.addEventListener('click', function () {
      // Restore submit state after reset
      predictBtn.disabled = false;
      if (predictBtn.dataset.orig) predictBtn.innerHTML = predictBtn.dataset.orig;
    });
  }

});
