# ============================================================
# Loan Approval Prediction - Flask Web Application
# ============================================================
# This file creates a simple localhost web app where users can:
#   - Enter loan applicant details in a form
#   - Click "Predict" to get Approved/Rejected result
#   - View the prediction with confidence score
#   - View model performance charts
# ============================================================

# -----------------------------------------------------------
# Import Required Libraries
# -----------------------------------------------------------
from flask import Flask, render_template, request
import joblib
import numpy as np
import os

# -----------------------------------------------------------
# Initialize Flask App
# -----------------------------------------------------------
app = Flask(__name__)

# -----------------------------------------------------------
# Load the Trained Model and Preprocessing Objects
# -----------------------------------------------------------
# These files are created by train_model.py
# Make sure to run train_model.py first!

# Check if model files exist
if not os.path.exists('model.pkl'):
    print("=" * 50)
    print("  ⚠️  ERROR: model.pkl not found!")
    print("  Please run 'python train_model.py' first")
    print("  to train the model and generate required files.")
    print("=" * 50)
    exit(1)

# Load the trained ML model
model = joblib.load('model.pkl')
print("✅ Model loaded successfully!")

# Load the feature scaler (used to normalize input data)
scaler = joblib.load('scaler.pkl')
print("✅ Scaler loaded successfully!")

# Load label encoders (to decode predictions)
label_encoders = joblib.load('label_encoders.pkl')
print("✅ Label encoders loaded successfully!")


# -----------------------------------------------------------
# Route 1: Home Page (Prediction Form)
# -----------------------------------------------------------
@app.route('/')
def home():
    """
    Renders the main page with the loan prediction form.
    Users fill in applicant details and submit for prediction.
    """
    return render_template('index.html')


# -----------------------------------------------------------
# Helper Function: Generate Explanation for Prediction
# -----------------------------------------------------------
def generate_explanation(is_approved, income, loan_amount, cibil_score, 
                         education, self_employed, no_of_dependents, total_assets):
    """
    Generate a truthful explanation for why the loan was approved/rejected.
    Based on key financial indicators.
    """
    explanation_parts = []
    
    # Debt-to-income ratio
    debt_to_income = loan_amount / income if income > 0 else float('inf')
    
    # Asset sufficiency
    asset_ratio = total_assets / loan_amount if loan_amount > 0 else 0
    
    # Credit score assessment
    if cibil_score >= 750:
        credit_status = "Excellent credit score ✅"
    elif cibil_score >= 650:
        credit_status = "Good credit score ✅"
    elif cibil_score >= 550:
        credit_status = "Fair credit score ⚠️"
    else:
        credit_status = "Poor credit score ❌"
    
    # Education assessment
    education_text = "Graduate education" if education == "Graduate" else "Non-graduate education"
    employment_text = "Self-employed" if self_employed == "Yes" else "Salaried"
    
    if is_approved:
        explanation_parts.append(f"✅ {credit_status}")
        if income >= 7500000:
            explanation_parts.append(f"✅ Sufficient annual income: ₹{income:,.0f}")
        if total_assets >= loan_amount * 0.5:
            explanation_parts.append(f"✅ Strong asset backing: ₹{total_assets:,.0f}")
        if debt_to_income < 2.5:
            explanation_parts.append(f"✅ Reasonable loan-to-income ratio: {debt_to_income:.1f}x")
        if education == "Graduate":
            explanation_parts.append(f"✅ {education_text}")
        if self_employed == "No":
            explanation_parts.append(f"✅ {employment_text} with stable income")
        if no_of_dependents <= 2:
            explanation_parts.append(f"✅ Low dependent count: {no_of_dependents}")
    else:
        # Rejection reasons
        if cibil_score < 550:
            explanation_parts.append(f"❌ {credit_status} — loan risky")
        if income < 2500000:
            explanation_parts.append(f"❌ Low annual income: ₹{income:,.0f}")
        if debt_to_income > 5:
            explanation_parts.append(f"❌ High loan-to-income ratio: {debt_to_income:.1f}x")
        if total_assets < loan_amount * 0.1:
            explanation_parts.append(f"❌ Insufficient assets: ₹{total_assets:,.0f}")
        if self_employed == "Yes" and education == "Not Graduate":
            explanation_parts.append(f"❌ Self-employed without graduate degree — risky profile")
        if no_of_dependents >= 4:
            explanation_parts.append(f"❌ High dependent count: {no_of_dependents}")
    
    return " • ".join(explanation_parts) if explanation_parts else "Decision made based on overall profile."


# -----------------------------------------------------------
# Route 2: Handle Prediction
# -----------------------------------------------------------
@app.route('/predict', methods=['POST'])
def predict():
    """
    Processes the form data and returns a loan prediction.

    Steps:
    1. Get form data from the user
    2. Encode categorical values (education, self_employed)
    3. Scale/normalize the features
    4. Use the trained model to make a prediction
    5. Return the result to the user
    """
    try:
        # --- Get form data ---
        # Categorical fields
        education = request.form.get('education', '').strip()
        self_employed = request.form.get('self_employed', '').strip()

        # Normalize common variants from UI/user inputs
        education_map = {
            'graduate': 'Graduate',
            'not graduate': 'Not Graduate'
        }
        self_emp_map = {
            'yes': 'Yes',
            'no': 'No'
        }
        education = education_map.get(education.lower(), education)
        self_employed = self_emp_map.get(self_employed.lower(), self_employed)

        # Numerical fields
        no_of_dependents = int(request.form.get('no_of_dependents', 0))
        income_annum = float(request.form.get('income_annum', 0))
        loan_amount = float(request.form.get('loan_amount', 0))
        loan_term = int(request.form.get('loan_term', 0))
        cibil_score = int(request.form.get('cibil_score', 0))
        residential_assets = float(request.form.get('residential_assets_value', 0))
        commercial_assets = float(request.form.get('commercial_assets_value', 0))
        luxury_assets = float(request.form.get('luxury_assets_value', 0))
        bank_assets = float(request.form.get('bank_asset_value', 0))

        # --- Encode categorical values ---
        # Convert text labels to numbers using saved encoders
        education_encoded = label_encoders['education'].transform([education])[0]
        self_employed_encoded = label_encoders['self_employed'].transform([self_employed])[0]

        # --- Prepare feature array ---
        # Order must match training data columns:
        # [no_of_dependents, education, self_employed, income_annum,
        #  loan_amount, loan_term, cibil_score, residential_assets_value,
        #  commercial_assets_value, luxury_assets_value, bank_asset_value]
        features = np.array([[
            no_of_dependents,
            education_encoded,
            self_employed_encoded,
            income_annum,
            loan_amount,
            loan_term,
            cibil_score,
            residential_assets,
            commercial_assets,
            luxury_assets,
            bank_assets
        ]])

        # --- Scale features ---
        features_scaled = scaler.transform(features)

        # --- Make prediction ---
        prediction = model.predict(features_scaled)[0]
        prediction_proba = model.predict_proba(features_scaled)[0]

        # --- Decode prediction ---
        result_label = label_encoders['loan_status'].inverse_transform([prediction])[0]
        confidence = round(max(prediction_proba) * 100, 1)

        # --- Determine status for UI styling ---
        is_approved = (result_label == 'Approved')
        
        # --- Calculate total assets ---
        total_assets = residential_assets + commercial_assets + luxury_assets + bank_assets
        
        # --- Generate explanation ---
        explanation = generate_explanation(is_approved, income_annum, loan_amount, 
                                          cibil_score, education, self_employed, 
                                          no_of_dependents, total_assets)

        # --- Return result to template ---
        return render_template('index.html',
                               prediction=result_label,
                               confidence=confidence,
                               is_approved=is_approved,
                               explanation=explanation,
                               # Pass form data back to keep form filled
                               form_data={
                                   'no_of_dependents': no_of_dependents,
                                   'education': education,
                                   'self_employed': self_employed,
                                   'income_annum': int(income_annum),
                                   'loan_amount': int(loan_amount),
                                   'loan_term': loan_term,
                                   'cibil_score': cibil_score,
                                   'residential_assets_value': int(residential_assets),
                                   'commercial_assets_value': int(commercial_assets),
                                   'luxury_assets_value': int(luxury_assets),
                                   'bank_asset_value': int(bank_assets)
                               })

    except Exception as e:
        # Handle any errors gracefully
        return render_template('index.html',
                       error=f"Error: {str(e)}. Please check your inputs.",
                       explanation="",
                       form_data=request.form)


# -----------------------------------------------------------
# Run the Flask Application
# -----------------------------------------------------------
if __name__ == '__main__':
    print("\n" + "=" * 50)
    print("  🚀 Loan Approval Prediction - Web App")
    print("  📍 Open: http://127.0.0.1:5000")
    print("  🛑 Press Ctrl+C to stop the server")
    print("=" * 50 + "\n")

    # Run on localhost, port 5000
    # debug=True enables auto-reload on code changes
    app.run(debug=True, host='127.0.0.1', port=5000)
