# ============================================================
# Loan Approval Prediction - Model Training & Evaluation
# ============================================================
# This script handles the complete ML pipeline:
#   1. Loading and exploring the dataset
#   2. Cleaning and preprocessing data
#   3. Encoding categorical features
#   4. Training multiple ML models
#   5. Evaluating model accuracy and performance
#   6. Generating visualizations for presentation
#   7. Saving the best model for Flask app
#   8. Testing predictions with sample data
# ============================================================

# -----------------------------------------------------------
# Step 1: Import Required Libraries
# -----------------------------------------------------------
import pandas as pd                    # For data manipulation
import numpy as np                     # For numerical operations
import matplotlib.pyplot as plt        # For creating charts/graphs
import seaborn as sns                  # For beautiful statistical plots
import joblib                          # For saving/loading the trained model
import os                              # For file/folder operations
import warnings                        # To suppress unnecessary warnings

# Scikit-learn imports for Machine Learning
from sklearn.model_selection import train_test_split    # Split data into train/test
from sklearn.preprocessing import LabelEncoder          # Convert text labels to numbers
from sklearn.preprocessing import StandardScaler        # Standardize/normalize features
from sklearn.linear_model import LogisticRegression     # Logistic Regression model
from sklearn.tree import DecisionTreeClassifier         # Decision Tree model
from sklearn.ensemble import RandomForestClassifier     # Random Forest model
from sklearn.metrics import (                           # Evaluation metrics
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Set plot style for better-looking graphs
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['font.size'] = 12

# Create 'static' folder to save charts (used by Flask app too)
os.makedirs('static', exist_ok=True)


# ============================================================
# Step 2: Load the Dataset
# ============================================================
print("=" * 60)
print("   LOAN APPROVAL PREDICTION - ML PROJECT")
print("=" * 60)

print("\n[Step 1] Loading the dataset...")
df = pd.read_csv('loan_approval_dataset.csv')

# Fix column names - remove leading/trailing spaces
df.columns = df.columns.str.strip()

print(f"   ✅ Dataset loaded successfully!")
print(f"   📊 Total Records: {df.shape[0]}")
print(f"   📋 Total Features: {df.shape[1]}")


# ============================================================
# Step 3: Explore the Dataset
# ============================================================
print("\n[Step 2] Exploring the dataset...\n")

# Show all column names and their data types
print("   Column Name                  | Data Type  | Non-Null Count")
print("   " + "-" * 62)
for col in df.columns:
    print(f"   {col:<30} | {str(df[col].dtype):<10} | {df[col].notna().sum()}")

# Show basic statistics
print(f"\n   📌 Dataset Shape: {df.shape}")
print(f"   📌 Missing Values: {df.isnull().sum().sum()}")

# Show target variable distribution
print(f"\n   📌 Loan Status Distribution:")
status_counts = df['loan_status'].value_counts()
for status, count in status_counts.items():
    percentage = (count / len(df)) * 100
    print(f"      - {status}: {count} ({percentage:.1f}%)")


# ============================================================
# Step 4: Data Cleaning & Preprocessing
# ============================================================
print("\n[Step 3] Cleaning and preprocessing data...")

# 4a. Drop the 'loan_id' column - it's just an identifier, not a feature
#     Loan ID doesn't help predict loan approval
df.drop('loan_id', axis=1, inplace=True)
print("   ✅ Dropped 'loan_id' column (not useful for prediction)")

# 4b. Handle missing values (if any)
#     Our dataset has no missing values, but this code handles them just in case
missing = df.isnull().sum()
if missing.sum() > 0:
    print("   ⚠️  Missing values found! Handling them now...")
    # Fill numerical columns with median (middle value - robust to outliers)
    numerical_cols = df.select_dtypes(include=['int64', 'float64']).columns
    for col in numerical_cols:
        if df[col].isnull().sum() > 0:
            df[col].fillna(df[col].median(), inplace=True)
            print(f"      - Filled '{col}' missing values with median: {df[col].median()}")

    # Fill categorical columns with mode (most frequent value)
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        if df[col].isnull().sum() > 0:
            df[col].fillna(df[col].mode()[0], inplace=True)
            print(f"      - Filled '{col}' missing values with mode: {df[col].mode()[0]}")
else:
    print("   ✅ No missing values found - dataset is clean!")

# 4c. Strip whitespace from categorical values
for col in df.select_dtypes(include=['object']).columns:
    df[col] = df[col].str.strip()

print("   ✅ Stripped whitespace from categorical columns")


# ============================================================
# Step 5: Encode Categorical Features
# ============================================================
# Machine Learning models need numbers, not text.
# We convert text categories to numerical values.
print("\n[Step 4] Encoding categorical features...")

# Initialize LabelEncoder
label_encoders = {}

# Columns that need encoding (text → numbers)
categorical_columns = ['education', 'self_employed', 'loan_status']

for col in categorical_columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le
    print(f"   ✅ Encoded '{col}': {dict(zip(le.classes_, le.transform(le.classes_)))}")

# Save label encoders for use in Flask app predictions
joblib.dump(label_encoders, 'label_encoders.pkl')
print("   ✅ Label encoders saved to 'label_encoders.pkl'")


# ============================================================
# Step 6: Feature Selection & Data Splitting
# ============================================================
print("\n[Step 5] Preparing features and splitting data...")

# Separate features (X) and target variable (y)
# X = all columns except 'loan_status' (input features)
# y = 'loan_status' column (what we want to predict)
X = df.drop('loan_status', axis=1)
y = df['loan_status']

print(f"   📌 Features (X): {list(X.columns)}")
print(f"   📌 Target (y): loan_status")
print(f"   📌 Feature count: {X.shape[1]}")

# Split data: 80% for training, 20% for testing
# random_state=42 ensures reproducible results (same split every time)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\n   📊 Training set size: {X_train.shape[0]} records ({X_train.shape[0]/len(df)*100:.0f}%)")
print(f"   📊 Testing set size:  {X_test.shape[0]} records ({X_test.shape[0]/len(df)*100:.0f}%)")

# Scale/Standardize features for better model performance
# StandardScaler makes all features have mean=0 and std=1
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Save the scaler for use in Flask app
joblib.dump(scaler, 'scaler.pkl')
print("   ✅ Features scaled using StandardScaler")
print("   ✅ Scaler saved to 'scaler.pkl'")

# Save feature names for Flask app
joblib.dump(list(X.columns), 'feature_names.pkl')


# ============================================================
# Step 7: Train Machine Learning Models
# ============================================================
print("\n" + "=" * 60)
print("   MODEL TRAINING")
print("=" * 60)

# Dictionary to store all models and their results
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42)
}

# Dictionary to store results for comparison
results = {}

# Train each model and evaluate
for name, model in models.items():
    print(f"\n{'─' * 50}")
    print(f"   🔄 Training: {name}")
    print(f"{'─' * 50}")

    # Train the model on training data
    model.fit(X_train_scaled, y_train)

    # Make predictions on test data
    y_pred = model.predict(X_test_scaled)

    # Calculate evaluation metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    # Store results for comparison
    results[name] = {
        'model': model,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'confusion_matrix': cm,
        'predictions': y_pred
    }

    # Display results
    print(f"   ✅ Accuracy:  {accuracy * 100:.2f}%")
    print(f"   ✅ Precision: {precision * 100:.2f}%")
    print(f"   ✅ Recall:    {recall * 100:.2f}%")
    print(f"   ✅ F1 Score:  {f1 * 100:.2f}%")

    # Display Confusion Matrix
    print(f"\n   📊 Confusion Matrix:")
    print(f"                        Predicted")
    print(f"                    Rejected  Approved")
    print(f"   Actual Rejected  [{cm[0][0]:>6}    {cm[0][1]:>6}]")
    print(f"   Actual Approved  [{cm[1][0]:>6}    {cm[1][1]:>6}]")

    # Display Classification Report
    print(f"\n   📋 Classification Report:")
    report = classification_report(y_test, y_pred, target_names=['Rejected', 'Approved'])
    for line in report.split('\n'):
        print(f"   {line}")


# ============================================================
# Step 8: Compare All Models
# ============================================================
print("\n" + "=" * 60)
print("   MODEL COMPARISON")
print("=" * 60)

# Create comparison table
print(f"\n   {'Model':<25} {'Accuracy':>10} {'Precision':>10} {'Recall':>10} {'F1 Score':>10}")
print("   " + "-" * 68)
for name, result in results.items():
    print(f"   {name:<25} {result['accuracy']*100:>9.2f}% {result['precision']*100:>9.2f}% "
          f"{result['recall']*100:>9.2f}% {result['f1_score']*100:>9.2f}%")

# Find the best model
best_model_name = max(results, key=lambda x: results[x]['accuracy'])
best_accuracy = results[best_model_name]['accuracy']

print(f"\n   🏆 BEST MODEL: {best_model_name}")
print(f"   🎯 Best Accuracy: {best_accuracy * 100:.2f}%")

# Explain why the best model performed better
print(f"\n   📝 Why {best_model_name} performed best:")
if best_model_name == 'Random Forest':
    print("   → Random Forest uses multiple decision trees and combines their predictions")
    print("   → This 'ensemble' approach reduces overfitting and improves accuracy")
    print("   → It handles both numerical and categorical features well")
    print("   → It captures complex non-linear relationships in loan data")
elif best_model_name == 'Decision Tree':
    print("   → Decision Tree creates clear if-else rules from the data")
    print("   → It captures non-linear patterns effectively")
    print("   → Works well when features have clear decision boundaries")
    print("   → Credit history and income create clear splits for loan decisions")
elif best_model_name == 'Logistic Regression':
    print("   → Logistic Regression works well for binary classification problems")
    print("   → The relationship between features and loan approval is mostly linear")
    print("   → It performs well with scaled/standardized features")
    print("   → Less prone to overfitting with proper regularization")


# ============================================================
# Step 9: Save the Best Model
# ============================================================
print("\n[Step 9] Saving the best model...")

best_model = results[best_model_name]['model']
joblib.dump(best_model, 'model.pkl')
print(f"   ✅ Best model ({best_model_name}) saved to 'model.pkl'")


# ============================================================
# Step 10: Generate Visualizations for Presentation
# ============================================================
print("\n[Step 10] Generating visualizations...")

# --- Chart 1: Accuracy Comparison Bar Chart ---
fig, ax = plt.subplots(figsize=(10, 6))
model_names = list(results.keys())
accuracies = [results[name]['accuracy'] * 100 for name in model_names]
colors = ['#6366F1', '#F59E0B', '#10B981']

bars = ax.bar(model_names, accuracies, color=colors, width=0.5, edgecolor='white', linewidth=2)

# Add value labels on top of bars
for bar, acc in zip(bars, accuracies):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
            f'{acc:.2f}%', ha='center', va='bottom', fontweight='bold', fontsize=14)

ax.set_title('Model Accuracy Comparison', fontsize=18, fontweight='bold', pad=15)
ax.set_ylabel('Accuracy (%)', fontsize=14)
ax.set_ylim(0, 105)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.savefig('static/accuracy_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/accuracy_comparison.png")

# --- Chart 2: Loan Approval Distribution ---
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Bar chart
status_labels = ['Approved', 'Rejected']
status_values = [status_counts.get('Approved', 0), status_counts.get('Rejected', 0)]
bar_colors = ['#10B981', '#EF4444']

bars = axes[0].bar(status_labels, status_values, color=bar_colors, width=0.5, edgecolor='white', linewidth=2)
for bar, val in zip(bars, status_values):
    axes[0].text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 20,
                 f'{val}', ha='center', va='bottom', fontweight='bold', fontsize=14)
axes[0].set_title('Loan Status - Count', fontsize=16, fontweight='bold')
axes[0].set_ylabel('Number of Applications', fontsize=12)
axes[0].spines['top'].set_visible(False)
axes[0].spines['right'].set_visible(False)

# Pie chart (robust to missing/NaN values)
status_values = [status_counts.get('Approved', 0) or 0, status_counts.get('Rejected', 0) or 0]
status_values = [0 if (v is None or (isinstance(v, float) and np.isnan(v))) else v for v in status_values]
total = sum(status_values)
if total == 0:
    # fallback: avoid pie with zero total
    status_values = [1, 0]

axes[1].pie(status_values, labels=status_labels, colors=bar_colors, autopct='%1.1f%%',
            startangle=90, textprops={'fontsize': 14, 'fontweight': 'bold'},
            wedgeprops={'edgecolor': 'white', 'linewidth': 2})
axes[1].set_title('Loan Status - Distribution', fontsize=16, fontweight='bold')

plt.tight_layout()
plt.savefig('static/loan_distribution.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/loan_distribution.png")

# --- Chart 3: Correlation Heatmap ---
fig, ax = plt.subplots(figsize=(12, 10))
correlation_matrix = df.corr()
mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
sns.heatmap(correlation_matrix, mask=mask, annot=True, fmt='.2f', cmap='RdYlBu_r',
            center=0, square=True, linewidths=1, cbar_kws={"shrink": 0.8},
            ax=ax, vmin=-1, vmax=1)
ax.set_title('Feature Correlation Heatmap', fontsize=18, fontweight='bold', pad=15)
plt.tight_layout()
plt.savefig('static/correlation_heatmap.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/correlation_heatmap.png")

# --- Chart 4: Feature Importance (from Random Forest) ---
fig, ax = plt.subplots(figsize=(10, 7))
rf_model = results['Random Forest']['model']
feature_importance = pd.Series(rf_model.feature_importances_, index=X.columns)
feature_importance = feature_importance.sort_values(ascending=True)

colors_gradient = plt.cm.RdYlGn(np.linspace(0.2, 0.9, len(feature_importance)))
bars = ax.barh(feature_importance.index, feature_importance.values, color=colors_gradient,
               edgecolor='white', linewidth=1)

# Add value labels
for bar, val in zip(bars, feature_importance.values):
    ax.text(val + 0.002, bar.get_y() + bar.get_height() / 2,
            f'{val:.3f}', ha='left', va='center', fontsize=11, fontweight='bold')

ax.set_title('Feature Importance (Random Forest)', fontsize=18, fontweight='bold', pad=15)
ax.set_xlabel('Importance Score', fontsize=14)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.savefig('static/feature_importance.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/feature_importance.png")

# --- Chart 5: Confusion Matrices for All Models ---
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for idx, (name, result) in enumerate(results.items()):
    cm = result['confusion_matrix']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[idx],
                xticklabels=['Rejected', 'Approved'],
                yticklabels=['Rejected', 'Approved'],
                cbar=False, linewidths=2, linecolor='white')
    axes[idx].set_title(f'{name}\nAccuracy: {result["accuracy"]*100:.2f}%',
                        fontsize=14, fontweight='bold')
    axes[idx].set_xlabel('Predicted', fontsize=12)
    axes[idx].set_ylabel('Actual', fontsize=12)

plt.suptitle('Confusion Matrices - All Models', fontsize=18, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('static/confusion_matrices.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/confusion_matrices.png")

# --- Chart 6: Metrics Comparison (Grouped Bar Chart) ---
fig, ax = plt.subplots(figsize=(12, 6))
metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
x = np.arange(len(metrics))
width = 0.22

for idx, (name, result) in enumerate(results.items()):
    values = [result['accuracy']*100, result['precision']*100,
              result['recall']*100, result['f1_score']*100]
    bars = ax.bar(x + idx * width, values, width, label=name,
                  color=colors[idx], edgecolor='white', linewidth=1)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                f'{val:.1f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

ax.set_ylabel('Score (%)', fontsize=14)
ax.set_title('Model Performance - All Metrics', fontsize=18, fontweight='bold', pad=15)
ax.set_xticks(x + width)
ax.set_xticklabels(metrics, fontsize=12)
ax.legend(fontsize=11, loc='lower right')
ax.set_ylim(0, 108)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.savefig('static/metrics_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("   ✅ Saved: static/metrics_comparison.png")


# ============================================================
# Step 11: Prediction Testing with Sample Data
# ============================================================
print("\n" + "=" * 60)
print("   PREDICTION TESTING")
print("=" * 60)

# Sample test cases to demonstrate prediction
test_samples = [
    {
        'description': 'High-income graduate with excellent credit',
        'data': {
            'no_of_dependents': 2,
            'education': 1,          # Graduate
            'self_employed': 0,      # No
            'income_annum': 9200000,
            'loan_amount': 12000000,
            'loan_term': 12,
            'cibil_score': 778,
            'residential_assets_value': 8200000,
            'commercial_assets_value': 3300000,
            'luxury_assets_value': 10700000,
            'bank_asset_value': 6400000
        }
    },
    {
        'description': 'Low-income non-graduate with poor credit',
        'data': {
            'no_of_dependents': 4,
            'education': 0,          # Not Graduate
            'self_employed': 0,      # No
            'income_annum': 2500000,
            'loan_amount': 8000000,
            'loan_term': 20,
            'cibil_score': 350,
            'residential_assets_value': 1200000,
            'commercial_assets_value': 500000,
            'luxury_assets_value': 2000000,
            'bank_asset_value': 800000
        }
    },
    {
        'description': 'Self-employed graduate with average credit',
        'data': {
            'no_of_dependents': 1,
            'education': 1,          # Graduate
            'self_employed': 1,      # Yes
            'income_annum': 5500000,
            'loan_amount': 15000000,
            'loan_term': 16,
            'cibil_score': 650,
            'residential_assets_value': 5000000,
            'commercial_assets_value': 2000000,
            'luxury_assets_value': 6000000,
            'bank_asset_value': 3500000
        }
    }
]

# Use the best model to make predictions
print(f"\n   Using: {best_model_name} (Best Model)\n")

for i, sample in enumerate(test_samples, 1):
    # Create DataFrame from sample data
    sample_df = pd.DataFrame([sample['data']])

    # Scale the features (same scaling as training data)
    sample_scaled = scaler.transform(sample_df)

    # Make prediction
    prediction = best_model.predict(sample_scaled)[0]
    prediction_proba = best_model.predict_proba(sample_scaled)[0]

    # Decode prediction
    result = "✅ APPROVED" if prediction == 0 else "❌ REJECTED"
    # Note: After label encoding, 0=Approved, 1=Rejected
    # Let's verify by checking the label encoder
    le_status = label_encoders['loan_status']
    result_label = le_status.inverse_transform([prediction])[0]
    result_emoji = "✅" if result_label == "Approved" else "❌"

    print(f"   Test Case {i}: {sample['description']}")
    print(f"   Income: ₹{sample['data']['income_annum']:,} | "
          f"Loan: ₹{sample['data']['loan_amount']:,} | "
          f"CIBIL: {sample['data']['cibil_score']}")
    print(f"   Prediction: {result_emoji} {result_label.upper()}")
    print(f"   Confidence: {max(prediction_proba) * 100:.1f}%")
    print()


# ============================================================
# Final Summary
# ============================================================
print("=" * 60)
print("   PROJECT COMPLETE!")
print("=" * 60)
print(f"""
   📁 Files Generated:
      - model.pkl              (Trained ML model)
      - scaler.pkl             (Feature scaler)
      - label_encoders.pkl     (Category encoders)
      - feature_names.pkl      (Feature names list)

   📊 Visualizations Saved in 'static/' folder:
      - accuracy_comparison.png
      - loan_distribution.png
      - correlation_heatmap.png
      - feature_importance.png
      - confusion_matrices.png
      - metrics_comparison.png

   🏆 Best Model: {best_model_name}
   🎯 Accuracy: {best_accuracy * 100:.2f}%

   🚀 Next Step: Run 'python app.py' to launch the Flask web app!
""")
